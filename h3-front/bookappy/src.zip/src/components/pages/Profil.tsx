
import NavBarHeader from '../NavigationAppli/NavBarHeader'

function Profil() {
    return (
        <div>
            <NavBarHeader/>
            Mon profil
        </div>
    )
}

export default Profil
