
import Navigation from '../NavigationAppli/Navigation'

function Welcome() {
    return (
        <div>
            <Navigation/>
        </div>
    )
}

export default Welcome
