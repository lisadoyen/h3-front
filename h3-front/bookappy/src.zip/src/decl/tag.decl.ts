export type Tag = {
    id: string;
    wording: string;
  };
  
  export type Tags = Tag[];