export type User = {
    id?: string;
    email?: string;
    lastName?:string;
    firstName?:string;
    password?:string;
    picture?:string;
  };
  export type Users = User[];